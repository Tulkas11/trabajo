from flask import Flask, jsonify, send_from_directory
from flask_restful import Api, Resource
from github import Github
import datetime
import os

app = Flask(__name__)
api = Api(app)

@app.route('/')
def home():
    return "Bienvenido a la API de Análisis de Perfiles de GitHub"

@app.route('/swagger.yaml')
def swagger_yaml():
    return send_from_directory(os.getcwd(), 'swagger.yaml')

class UserInsights(Resource):
    def get(self, username):
        insights = get_user_insights(username)
        return jsonify(insights)

api.add_resource(UserInsights, '/user-insights/<string:username>')

def get_user_insights(username):
    g = Github('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')  # Reemplaza con tu token de GitHub
    user = g.get_user(username)

    insights = {
        "top_languages": get_top_languages(user),
        "top_repos": get_top_repos(user),
        "contributions": get_contributions(user),
        "activity": get_activity(user)
    }
    return insights

def get_top_languages(user):
    languages = {}
    for repo in user.get_repos():
        repo_languages = repo.get_languages()
        for lang, lines in repo_languages.items():
            if lang in languages:
                languages[lang] += lines
            else:
                languages[lang] = lines
    sorted_languages = sorted(languages.items(), key=lambda x: x[1], reverse=True)
    return [lang for lang, _ in sorted_languages[:3]]

def get_top_repos(user):
    repos = []
    for repo in user.get_repos():
        prs = repo.get_pulls(state='closed')
        merged_prs = [pr for pr in prs if pr.is_merged()]
        repos.append((repo.name, len(merged_prs)))
    sorted_repos = sorted(repos, key=lambda x: x[1], reverse=True)
    return [repo for repo, _ in sorted_repos[:3]]

def get_contributions(user):
    today = datetime.datetime.now()
    six_months_ago = today - datetime.timedelta(days=6*30)
    contributions = {"pull_requests": [], "issues": [], "commits": []}

    for event in user.get_events():
        if event.created_at >= six_months_ago:
            if event.type == 'PullRequestEvent':
                contributions["pull_requests"].append(event)
            elif event.type == 'IssuesEvent':
                contributions["issues"].append(event)
            elif event.type == 'PushEvent':
                contributions["commits"].append(event)
    
    return {
        "pull_requests": len(contributions["pull_requests"]),
        "issues": len(contributions["issues"]),
        "commits": len(contributions["commits"]),
    }

def get_activity(user):
    activity = {"morning": 0, "afternoon": 0, "evening": 0}
    for event in user.get_events():
        hour = event.created_at.hour
        if 6 <= hour < 12:
            activity["morning"] += 1
        elif 12 <= hour < 18:
            activity["afternoon"] += 1
        elif 18 <= hour < 24:
            activity["evening"] += 1
    return activity

from flask_swagger_ui import get_swaggerui_blueprint

SWAGGER_URL = '/swagger'
API_URL = '/swagger.yaml'

swaggerui_blueprint = get_swaggerui_blueprint(SWAGGER_URL, API_URL, config={'app_name': "GitHub Profile Analysis"})
app.register_blueprint(swaggerui_blueprint, url_prefix=SWAGGER_URL)

if __name__ == '__main__':
    app.run(debug=True)
